//  ShrinkTheFlushLessOften2023x
//  Created by SDBX on 26/7/2023.

import Foundation
import BigInt

print("Hello, World!")

func genRandomBlock(length: Int) -> [UInt8] {
    var randomBytes: [UInt8] = Array(repeating: 0x00, count: length);
    for rng in 0..<randomBytes.count {
        let value = UInt8.random(in: 0x00...0xFF); // TODO: SDBX
        randomBytes[rng] = value;
    }
    return randomBytes;
}
// let randomBlk = genRandomBlock(length: 256);


func testForFailures(inputBlock: [UInt8]) -> BigUInt? {
    // var SERIES_FLUSH: [UInt8] = Array(0x00...0xFF);
    var SERIES_FLUSH: [UInt8] = Set(inputBlock).sorted();
    var PAST_16_VALUES_: [UInt8] = [];
    
    func updatePast16values(with: UInt8) {
        if !(PAST_16_VALUES_.contains(with)) {
            PAST_16_VALUES_.append(with);
        }
        if (PAST_16_VALUES_.count > 16) {
            PAST_16_VALUES_.removeFirst();
        }
        // [OK]: print("PAST_16_VALUES_:", PAST_16_VALUES_.count)
    }
    
    var BIGNUM: BigUInt = 0;
    for w in 0..<1 {
        for x in 0..<256 {
            let offset = w*256+x;
            let value = inputBlock[offset];
            updatePast16values(with: value);
            let index = SERIES_FLUSH.firstIndex(of: value);
            if (index != nil) {
                BIGNUM += BigUInt(index!);
                BIGNUM.multiply(byWord: BigUInt.Word(SERIES_FLUSH.count));
                SERIES_FLUSH.remove(at: index!);
            } else {
                if let index: Int = Array(PAST_16_VALUES_).sorted().firstIndex(of: value) { // FORCED
                    BIGNUM += BigUInt(index);
                    BIGNUM.multiply(byWord: BigUInt.Word(PAST_16_VALUES_.count));
                } else {
                    return nil
                }
            }
        }
        /* for value in PAST_VALUES_ {
         SERIES_FLUSH.removeAll(where: {$0 == value});
         } */
        // PAST_VALUES_.removeAll(); // TODO: <--- SDBX (This is what everyone has been missing!)
    }
    // [OK]: print(BIGNUM.bitWidth, "bits.")
    return BIGNUM;
}

let testBlock_RLE_: [UInt8] = Array(repeating: 0x7F, count: 256);
let output = testForFailures(inputBlock: testBlock_RLE_);
print(output, output?.bitWidth, "bits..");
sleep(5);

func main1() {
    let start = Date();
    for test in 1...60_000_000 {
        let randomBlock = genRandomBlock(length: 256);
        if let output = testForFailures(inputBlock: randomBlock) {
            if (test % 1000 == 0) {
                print(test, ":", output.bitWidth, "bits. (compressed?)");
            }
        } else {
            print(test, ":", " * FAILURE: FAILED TO COMPRESS INPUT.")
        }
    }
    let elapsed: TimeInterval = -start.timeIntervalSinceNow;
    print(elapsed, "seconds.")
}


// ********

let inputFile: String = "/Users/%USERNAME%/Downloads/ubuntu-23.04-desktop-legacy-amd64.iso.7z";
let inputURL:  URL    = URL(fileURLWithPath: inputFile);

let INPUT_DATA: Data  = try Data(contentsOf: inputURL, options: .mappedIfSafe);

let JUST_1MB_ALIGNED = INPUT_DATA.count / (1024*1024);// * (1024*1024);

print("Reading just the first \(JUST_1MB_ALIGNED) MB...")

let start = Date();

// for w in stride(from: 0, to: JUST_1MB_ALIGNED, by: +1024*1024) {
DispatchQueue.concurrentPerform(iterations: JUST_1MB_ALIGNED, execute: { idxGCD in
    let offset = idxGCD * (1024*1024);
    let range   = offset..<offset+(1024*1024)
    let subData = INPUT_DATA.subdata(in: range)
    
    for x in stride(from: 0, to: (1024*1024), by: +256) {
        let offset = x;
        let subBlock = Array(subData[offset..<offset+256]);
        if let OK = testForFailures(inputBlock: subBlock) {
            if (OK.bitWidth >= 184*8) {
                print(idxGCD, ":", OK.bitWidth, "bits out.")
            }
        } else {
            print(idxGCD, ":", " * FAILURE: FAILED TO COMPRESS INPUT.")
        }
    }
})

let elapsed: TimeInterval = -start.timeIntervalSinceNow;
print(elapsed, "seconds.")

// ********

print("Goodbye.")
sleep(60);
